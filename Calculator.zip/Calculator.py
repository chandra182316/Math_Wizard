def calculate(operand1, operator, operand2):
    if operator == "+":
        return operand1 + operand2
    elif operator == "-":
        return operand1 - operand2
    elif operator == "*":
        return operand1 * operand2
    elif operator == "/":
        if operand2 != 0:
            return operand1 / operand2
        else:
            return "Cannot divide by zero"
    else:
        return "Invalid operator"

def main():
    while True:
        expression = input("Enter a mathematical expression (e.g., 2 + 3): ")
        parts = expression.split()

        if len(parts) != 3:
            print("Invalid expression format.")
            continue

        operand1 = float(parts[0])
        operator = parts[1]
        operand2 = float(parts[2])

        result = calculate(operand1, operator, operand2)
        print("Result:", result)

        play_again = input("Do you want to perform another calculation? (yes/no): ").lower()
        if play_again != "yes":
            break

    print("Calculator closed.")

if __name__ == "__main__":
    main()
